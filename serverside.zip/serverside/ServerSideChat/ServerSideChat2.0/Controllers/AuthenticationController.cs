﻿using Microsoft.AspNetCore.Mvc;

namespace ServerSideChat2._0.Controllers
{
    public class AuthenticationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
