﻿using Microsoft.EntityFrameworkCore;

namespace ServerSideChat.Properties.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions options) : base(options)
        {

        }
    }
}
