var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
//string connectionString = builder.Configuration["ConnectionStrings:PetShopConnection"]!;
//builder.Services.AddDbContext<DataContext>(options => options.UseSqlite(connectionString));
builder.Services.AddCors(o => o.AddPolicy("Mashu", policy =>
{
    policy.AllowAnyHeader().AllowAnyOrigin().AllowAnyMethod();
}));

var app = builder.Build();

//using (var scope = app.Services.CreateScope())
//{
//    var ctx = scope.ServiceProvider.GetRequiredService<DataContext>();
//    ctx.Database.EnsureDeleted();
//    ctx.Database.EnsureCreated();
//}

app.UseCors("Mashu");
app.UseStaticFiles();
app.UseRouting();

app.MapDefaultControllerRoute();

app.Run();